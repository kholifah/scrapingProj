From the command line navigate to this folder and run:
> npm install

Navigate into the pintProj folder and type:
> node app 

And navigate to http://localhost:8080
